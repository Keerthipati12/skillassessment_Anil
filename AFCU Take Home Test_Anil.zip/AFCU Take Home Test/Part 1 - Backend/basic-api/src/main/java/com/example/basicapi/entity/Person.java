package com.example.basicapi.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Person {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "SequenceSubCategoryId")
    @SequenceGenerator(name = "SequenceSubCategoryId", sequenceName = "PERSON_SEQ")
    private int id;

    private String accountId;

    private String address;

    private String firstName;

    private String lastName;
}
