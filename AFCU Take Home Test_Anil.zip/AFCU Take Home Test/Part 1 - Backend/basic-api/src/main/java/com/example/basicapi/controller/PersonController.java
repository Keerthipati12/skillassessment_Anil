package com.example.basicapi.controller;

import com.example.basicapi.entity.Person;
import com.example.basicapi.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/person")
@CrossOrigin("http://localhost:4200")
public class PersonController {

    @Autowired
    private PersonService personService;

    @GetMapping("/")
    public List<Person> findAll() {
        return personService.findAllPersons();
    }

    @GetMapping("/{id}")
    public Optional<Person> findById(@PathVariable(name = "id") int id) {
        return personService.findById(id);
    }

    @GetMapping("/accountid/{accountid}")
    public List<Person> findbyAccountId(@PathVariable(name = "accountid") String accountid) {
        return personService.findbyAccountId(accountid);
    }

    @PutMapping("/add")
    public Person addPerson(@RequestBody Person person){
        return personService.addPerson(person);
    }
}
