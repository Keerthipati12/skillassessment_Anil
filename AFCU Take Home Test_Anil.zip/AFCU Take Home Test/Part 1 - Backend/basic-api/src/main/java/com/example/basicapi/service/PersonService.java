package com.example.basicapi.service;

import com.example.basicapi.entity.Person;
import com.example.basicapi.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PersonService {

    @Autowired
    private PersonRepository personRepository;

    public List<Person> findAllPersons() {
        return personRepository.findAll();
    }

    public Optional<Person> findById(int id) {
        return personRepository.findById(id);
    }

    public List<Person> findbyAccountId(String accountid) {
        return personRepository.findByAccountId(accountid);
    }

    public Person addPerson(Person person) {
        personRepository.saveAndFlush(person);
        return person;
    }
}
