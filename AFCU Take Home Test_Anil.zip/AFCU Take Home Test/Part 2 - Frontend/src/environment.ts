export const environment = {
    backendurl: 'http://localhost:8080',
    options : {
      headers: {
          "Content-Type": 'application/json',
          "Access-Control-Allow-Origin": '*',
          "Authorization": "",
          "userId":""
      },

      credentials: 'same-origin',
  }
  }; 