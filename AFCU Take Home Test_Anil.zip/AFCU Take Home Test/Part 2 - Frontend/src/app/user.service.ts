import { Injectable} from '@angular/core';
import axios from 'axios';
import { environment } from '../environment';
import { Person } from './model/Person';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor() { }

  addPersion(person :Person) {
    const data = JSON.stringify(person);

    axios.put(environment.backendurl + "/person/add", data,
        environment.options).then(response => {
          alert(response.data);
          person.id = response.data.id;
            alert("person added successfully");
        })
        .catch(error => {
            console.error(error);
        });
  }

  findById(id :number) {
    var fileItems = new Array();
    axios.get(environment.backendurl +"/person/" + id).then(response => {
      // Handle successful response
      //console.log(response.data);
      var person = new Person();
      person.id = response.data.id;
      person.accountId = response.data.accountId;
      person.address = response.data.address;
      person.firstName = response.data.firstName;
      person.lastName = response.data.lastName;
      fileItems.push(person);
      return true;
    })
      .catch(error => {
        console.error(error);
        return false;
      });

      return fileItems;
  }

  findByAccountID(accountId :string) {
    var fileItems = new Array();
    axios.get(environment.backendurl +"/person/accountid/" + accountId).then(response => {
      for (var i=0; i<response.data.length; i++) {
        var person = new Person();
        person.id = response.data[i].id
        person.accountId = response.data[i].accountId;
        person.address = response.data[i].address;
        person.firstName = response.data[i].firstName;
        person.lastName = response.data[i].lastName;
        fileItems.push(person);
      }
    })
      .catch(error => {
        console.error(error);
        return false;
      });

      return fileItems;
  }
}
