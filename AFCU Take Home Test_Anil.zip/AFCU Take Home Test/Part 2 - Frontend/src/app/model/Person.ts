export class Person {
    public id: number;
    public accountId: string;
    public firstName: string;
    public lastName: string;
    public address: string;
}