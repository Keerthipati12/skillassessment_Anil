import { Component } from '@angular/core';
import { ReactiveFormsModule, Validators } from '@angular/forms';
import { FormControl, FormGroup } from '@angular/forms';
import { Person } from '../model/Person';
import { UserService } from '../user.service';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-createuser',
  standalone: true,
  imports: [ReactiveFormsModule, NgIf],
  templateUrl: './createuser.component.html',
  styleUrl: './createuser.component.css'
})
export class CreateuserComponent {

  userService: UserService = new UserService();
  person :Person;
  showMyContainer: boolean = false;
   myForm = new FormGroup({
    accountId: new FormControl<string>('', Validators.required),
    firstName: new FormControl<string>('', Validators.required),
    lastName: new FormControl<string>('', Validators.required),
    address: new FormControl<string>('', Validators.required),
   })

   onSubmit() {
        this.person = new Person();
        this.person.accountId = this.myForm.value['accountId'];
        this.person.firstName = this.myForm.value['firstName'];
        this.person.lastName = this.myForm.value['lastName'];
        this.person.address = this.myForm.value['address'];
        this.userService.addPersion(this.person);
        this.showMyContainer = true;
   }
}
