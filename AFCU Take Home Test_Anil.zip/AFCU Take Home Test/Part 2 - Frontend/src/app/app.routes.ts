import { Routes } from '@angular/router';
import { CreateuserComponent } from './createuser/createuser.component';
import { SearchComponent } from './search/search.component';

export const routes: Routes = [
    {path: "create", component: CreateuserComponent}, 
    {path: "search", component: SearchComponent}
];
