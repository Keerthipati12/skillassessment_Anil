import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { DataTablesModule } from 'angular-datatables';
import { Person } from '../model/Person';
import { UserService } from '../user.service';
import { NgFor } from '@angular/common';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [ReactiveFormsModule, DataTablesModule, NgFor],
  templateUrl: './search.component.html',
  styleUrl: './search.component.css'
})
export class SearchComponent {
  userService: UserService = new UserService();
  searchForm = new FormGroup({
    id: new FormControl<number>(null),
    accountId: new FormControl<string>(''),
   })
   
   dtOptions = {
    
    };
    dtTrigger: Subject<any> = new Subject<any>();
    persons: Array<any>;


   onSubmit() {
    const id = this.searchForm.value['id'];
    const accountId = this.searchForm.value['accountId'];

    if (id == null && accountId == null) return;

    if (id != null)
        this.persons = this.userService.findById(id);
    
    else 
        this.persons = this.userService.findByAccountID(accountId);
   }
}
